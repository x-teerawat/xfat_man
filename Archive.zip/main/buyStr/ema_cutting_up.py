def ema_cutting_up(self):
    try:
        if self.log_data.loc[self.previous_time, f'IsEMACuttingUp__{self.list_n_time_frames[0]}'] == 1:
            self.IsBuySignal = 1
        else:
            self.IsBuySignal = 0
    except:
        self.IsBuySignal = 0

    ### Update
    self.log_data.loc[self.current_time, 'IsBuySignal'] = self.IsBuySignal
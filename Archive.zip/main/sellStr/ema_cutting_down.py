def ema_cutting_down(self):
    try:
        if self.log_data.loc[self.previous_time, f'IsEMACuttingDown__{self.list_n_time_frames[0]}'] == 1:
            self.IsSellSignal = 1
        else:
            self.IsSellSignal = 0
    except:
        self.IsSellSignal = 0

    ### Update
    self.log_data.loc[self.current_time, 'IsSellSignal'] = self.IsSellSignal
class ForwardTesting():
    def run_forward_testing(self):
        print("run_forward_testing")
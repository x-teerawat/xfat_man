from _libraries import *
from _functions import *

from get_data import get_data
from prepare_data import prepare_data
from clean_data import clean_data

### Buy strategies
sys.path.insert(0, '/Users/x/Documents/GitHub/xwealth/main/buyStr')
from ema_cutting_up import ema_cutting_up
### Sell strategies
sys.path.insert(0, '/Users/x/Documents/GitHub/xwealth/main/sellStr')
from ema_cutting_down import ema_cutting_down
from force_sell import force_sell

class Utils():
    def run_strategy(self):
        ### Update data
        self.existing_data = pd.concat([self.existing_data, self.new_data])
        self.all_new_data = pd.concat([self.all_new_data, self.new_data])
        self.log_data = pd.concat([self.log_data, self.new_data])

        ### Determine time
        self.current_time = self.log_data.index[-1]
        try:
            self.previous_time = self.log_data.index[-2]
        except:
            pass

        ### Check and update missing times
        check_and_update_missing_times(self)

        ema_cutting_up(self)
        ema_cutting_down(self)
        force_sell(self)

        ### Check and update status
        check_and_update_status(self)

        ### Compute NAV
        compute_nav(self)

        ###
        for self.n_time_frames in self.list_n_time_frames:
            self.selected_position_nth = search_updated_position(self)

            if len(self.all_new_data) % self.n_time_frames != 0:
                ### Genterate time in multi time frames
                self.time_in_multi_time_frames = generate_time_in_multi_time_frames(self.all_new_data, self.n_time_frames, self.selected_position_nth, self.round_nth_of_multi_time_frames) # Must be self.time_in_multi_time_frames because update only necessary
                
            else:
                ### Convert 1s time frame to other time frame data
                convert_new_data_to_multi_time_frames(self)

                ### Selected ...
                self.selected_round_nth = self.round_nth_of_multi_time_frames[self.selected_position_nth]
                self.selected_existing_data = self.existing_data_of_multi_time_frames[self.selected_position_nth]
                self.selected_all_new_data = self.all_new_data_of_multi_time_frames[self.selected_position_nth]
                self.current_time_of_multi_time_frames = self.converted_new_data_of_multi_time_frames.index[0]
                try:
                    self.previous_time_of_multi_time_frames = self.selected_all_new_data.index[-2]
                except:
                    pass

                ### Compte EMA
                compute_ema(self)

                ### Search AB interfaces
                search_ab_interfaces(self)
                
                ### Search EMA cutting down
                search_ema_cutting_up_and_down(self)

                ### Compute pivots for plotting
                # self.compute_pivots_for_plotting()
                ### Plot
                plot(self)

                self.round_nth_of_multi_time_frames[self.selected_position_nth] += 1

            ### Update time_in_multi_time_frames in log_data
            self.log_data.loc[self.current_time, f'time_in_multi_time_frames__{self.n_time_frames}'] = self.time_in_multi_time_frames
            try:
                self.log_data.loc[self.current_time, f'IsEMACuttingUp__{self.n_time_frames}'] = self.IsEMACuttingUp
                self.log_data.loc[self.current_time, f'IsEMACuttingDown__{self.n_time_frames}'] = self.IsEMACuttingDown
            except:
                self.log_data.loc[self.current_time, f'IsEMACuttingUp__{self.n_time_frames}'] = np.nan
                self.log_data.loc[self.current_time, f'IsEMACuttingDown__{self.n_time_frames}'] = np.nan
                

        verbose(self)

        self.round_nth += 1

    
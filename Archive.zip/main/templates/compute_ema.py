from _libraries import *

def compute_ema(self):
    for n_ema in self.list_n_ema:
        ema_values = ta.ema(self.selected_existing_data.close, n_ema)[-1]

        ### Update
        self.selected_all_new_data.loc[self.current_time_of_multi_time_frames, f"ema_{n_ema}"] = ema_values
    
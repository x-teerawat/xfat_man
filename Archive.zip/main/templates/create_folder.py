from _libraries import *

### Create a folder
def create_folder(self):
    if self.save_plot:
        try:
            self.folder_name = f"plot__stock_name_{self.stock_name}__buy_strategy_{self.buy_strategy}__sell_strategy_{self.sell_strategy}__test_date_{self.test_date}__up_thresh_{self.up_thresh}__down_thresh_{self.down_thresh}"
            os.mkdir(self.folder_name)
        except:
            pass
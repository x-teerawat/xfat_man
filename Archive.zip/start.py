import sys
sys.path.insert(0, '/Users/x/Documents/GitHub/xwealth/main/templates')
from _backtesting import Backtesting
from _forward_testing import ForwardTesting

if __name__=="__main__":
    Backtesting(
        stock_name="TQQQ",
        list_n_ema=[12, 24],
        list_n_time_frames=[15], # Unit: second
        initial_cash=100000,
        n_cut_loss=-0.3,
        buy_strategy = "sg_tf_hl", # sg_tf_hl
        sell_strategy = "sg_tf_lh_or_ema_crossunder", # sg_tf_lh, sg_tf_ema_crossunder, sg_tf_lh_or_ema_crossunder, sg_tf_ema_crossunder_and_lh
        test_date = "2024-01-18",
        maker_fees = 0.002,
        taker_fees = 0.002,
        up_thresh = 0.001,
        down_thresh = -0.001,
        show_verbose=True,
        # show_plot=True,
        save_plot=True,
    ).run_backtesting()
